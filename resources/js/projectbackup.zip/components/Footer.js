import React from 'react';

function Footer() {

    return (
        <footer className="footer">
           hello footer
        </footer>
    );
}

export default Footer;