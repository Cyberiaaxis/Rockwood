import React from "react";
export default function Forums() {
    return (
        <div>
            Welcome on forums page
        </div>
    );
}